# Independently recount four absolute input channels at fixed Qwen K=2048.
BEGIN { fields[0]=3; fields[31]=34; fields[32]=37; fields[2047]=2176 }
NF!=2176 { bad=1; exit 2 }
{ for(channel in fields) histogram[channel,$fields[channel]]++ }
END {
    if(bad) exit 2
    for(channel in fields) {
        printf "{\"input_channel\":%d,\"histogram\":[",channel
        for(value=0;value<256;value++) printf "%s%d",(value?",":""),histogram[channel,value]+0
        print "]}"
    }
}
