#!/usr/bin/env perl
use v5.36;
use JSON::PP ();
use POSIX qw(ceil);
use Test::More ();

# Return Shannon entropy of observed bytes, not an encoded-stream size.
sub calculate_entropy ($histogram, $total) {
    my $entropy = 0.0;
    for my $count (@$histogram) {
        next if $count == 0;
        my $probability = $count / $total;
        $entropy -= $probability * log($probability) / log(2);
    }
    return $entropy;
}

# Parse original Q8_0 blocks; scale bits never enter payload histograms.
sub analyze_bytes ($bytes, $k, $n) {
    die "invalid shape\n" unless $k > 0 && $k % 32 == 0 && $k <= 4096 && $n > 0;
    my $blocks_per_column = $k / 32;
    my $expected = $blocks_per_column * $n * 34;
    die "tensor size mismatch\n" unless length($bytes) == $expected && $expected <= 64 * 1024 * 1024;
    my @global = (0) x 256;
    my @counts = (0) x ($k * 256);
    for (my $block = 0; $block < $blocks_per_column * $n; ++$block) {
        my $first_channel = ($block % $blocks_per_column) * 32;
        my @payload = unpack('C32', substr($bytes, $block * 34 + 2, 32));
        for my $position (0 .. 31) {
            my $byte = $payload[$position];
            ++$counts[($first_channel + $position) * 256 + $byte];
            ++$global[$byte];
        }
    }
    my @channels;
    my $ideal_bits = 0.0;
    for my $channel (0 .. $k - 1) {
        my @histogram = @counts[$channel * 256 .. $channel * 256 + 255];
        my $sum = 0;
        $sum += $_ for @histogram;
        die "channel count mismatch\n" unless $sum == $n;
        my $entropy = calculate_entropy(\@histogram, $n);
        $ideal_bits += $entropy * $n;
        push @channels, {input_channel => $channel, histogram => \@histogram, entropy_bits => $entropy};
    }
    my $payload_symbols = $k * $n;
    my $scale_bytes = $blocks_per_column * $n * 2;
    my $code_length_bytes = $k * 256;
    my $index_bytes = $k * ceil($n / 256) * 4;
    my $ideal_payload_bytes = ceil($ideal_bits / 8);
    my $optimistic_bytes = $ideal_payload_bytes + $scale_bytes + $code_length_bytes + $index_bytes;
    return {
        k => $k, n => $n, source_bytes => $expected, payload_symbols => $payload_symbols,
        scale_bytes => $scale_bytes, pooled_histogram => \@global,
        pooled_entropy_bits => calculate_entropy(\@global, $payload_symbols),
        conditional_entropy_bits => $ideal_bits / $payload_symbols,
        ideal_conditional_payload_bits => $ideal_bits, ideal_conditional_payload_bytes => $ideal_payload_bytes,
        code_length_table_bytes => $code_length_bytes, index_bytes => $index_bytes,
        output_symbols_per_index_chunk => 256, optimistic_stored_bytes => $optimistic_bytes,
        optimistic_stored_byte_saving => 1 - $optimistic_bytes / $expected,
        channels => \@channels, has_materialized_encoded_stream => JSON::PP::false,
        has_encoder => JSON::PP::false, has_decoder => JSON::PP::false,
        has_measured_speedup => JSON::PP::false, includes_alignment_or_decoder_cost => JSON::PP::false,
    };
}

# Build actual block bytes with independently chosen payloads for behavioral checks.
sub build_tensor ($k, $n, $choose_byte, $scale) {
    my $bytes = '';
    for my $column (0 .. $n - 1) {
        for my $block (0 .. $k / 32 - 1) {
            $bytes .= pack('v', $scale);
            $bytes .= pack('C32', map { $choose_byte->($block * 32 + $_, $column) } 0 .. 31);
        }
    }
    return $bytes;
}

# Verify observable distributions, channel mapping, metadata costs and rejection.
sub run_self_tests () {
    my $ramp = build_tensor(32, 32, sub ($channel, $column) { $channel }, 0x8000);
    my $stats = analyze_bytes($ramp, 32, 32);
    Test::More::ok(abs($stats->{pooled_entropy_bits} - 5) < 1e-12, 'pooled channel constants have five bits');
    Test::More::is($stats->{conditional_entropy_bits}, 0, 'known input coordinate removes channel-constant entropy');
    Test::More::is($stats->{channels}[15]{histogram}[15], 32, 'channel identity survives output-column traversal');
    Test::More::is($stats->{payload_symbols}, 1024, 'every payload byte is counted');
    Test::More::is($stats->{scale_bytes}, 64, 'literal scales remain in storage');
    my $different_scales = build_tensor(32, 32, sub ($channel, $column) { $channel }, 0x7fff);
    Test::More::is_deeply(analyze_bytes($different_scales, 32, 32), $stats, 'scale bits do not enter distributions');
    my $uniform = analyze_bytes(build_tensor(32, 256, sub ($channel, $column) { $column }, 0), 32, 256);
    Test::More::is($uniform->{conditional_entropy_bits}, 8, 'all 256 byte values remain uniform in every channel');
    Test::More::is($uniform->{pooled_entropy_bits}, 8, 'uniform pooled distribution remains eight bits');
    Test::More::is($uniform->{code_length_table_bytes}, 8192, 'code-length tables are charged per channel');
    my $tail = analyze_bytes(build_tensor(32, 257, sub ($channel, $column) { $column % 256 }, 0), 32, 257);
    Test::More::is($tail->{index_bytes}, 256, 'ragged output chunk needs a second index per channel');
    my $two_blocks = analyze_bytes(build_tensor(64, 3, sub ($channel, $column) { $channel }, 1), 64, 3);
    Test::More::is($two_blocks->{channels}[63]{histogram}[63], 3, 'multiple input blocks retain absolute channel positions');
    Test::More::ok(!eval { analyze_bytes($ramp, 32, 0); 1 }, 'zero output width rejected');
    Test::More::ok(!eval { analyze_bytes(substr($ramp, 1), 32, 32); 1 }, 'truncated tensor rejected');
    Test::More::ok(!eval { analyze_bytes($ramp, 33, 32); 1 }, 'partial input block rejected');
    Test::More::is_deeply(analyze_bytes($ramp, 32, 32), $stats, 'repeated analysis returns identical observations');
    Test::More::done_testing();
    return;
}

if (@ARGV == 1 && $ARGV[0] eq '--self-test') {
    run_self_tests();
    exit(Test::More->builder->is_passing ? 0 : 1);
}
die "usage: $0 raw-q8-tensor K N\n" unless @ARGV == 3;
my ($path, $k, $n) = @ARGV;
die "invalid dimensions\n" unless $k =~ /^\d+$/ && $n =~ /^\d+$/;
my $size = -s $path;
die "tensor exceeds raw bound\n" unless defined($size) && $size <= 64 * 1024 * 1024;
open my $input, '<:raw', $path or die "open tensor: $!\n";
my $bytes = do { local $/; <$input> };
close $input or die "close tensor: $!\n";
my $stats = analyze_bytes($bytes, 0 + $k, 0 + $n);
open my $maps, '<', "/proc/$$/maps" or die "read process maps: $!\n";
my @cuda_libraries = grep { /libcuda(?:rt)?\.so/ } <$maps>;
close $maps;
die "unexpected CUDA library\n" if @cuda_libraries;
print JSON::PP->new->canonical->encode({kind => 'channel_entropy_tensor', process_id => $$,
    loaded_cuda_libraries => \@cuda_libraries, statistics => $stats}), "\n";
