#!/usr/bin/env bash
# Verify exact selected-channel byte positions and malformed-row rejection.
set -euo pipefail
awk 'BEGIN { for(column=0;column<3;column++) { for(field=1;field<=2176;field++) printf "%s%d",(field==1?"":" "),(field+column)%256; print "" } }' |
  awk -f /tmp/m40-channel-recount.awk |
  jq -es 'length==4 and (map(.input_channel)|sort)==[0,31,32,2047]
    and all(.[];. as $check | (if .input_channel==0 then 3 elif .input_channel==31 then 34
      elif .input_channel==32 then 37 else 2176 end) as $field |
      all(range(0;256);. as $value|$check.histogram[$value]==
        ([range(0;3)|select((($field+.)%256)==$value)]|length)))'
if awk 'BEGIN { for(field=0;field<2175;field++) printf "0 "; print "" }' |
    awk -f /tmp/m40-channel-recount.awk > /dev/null; then
  printf 'Malformed row was incorrectly accepted\n' >&2
  exit 1
fi
printf 'Exact positions and malformed-row rejection pass\n'
