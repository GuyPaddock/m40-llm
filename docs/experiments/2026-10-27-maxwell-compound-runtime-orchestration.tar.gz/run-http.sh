#!/usr/bin/env bash
set -euo pipefail
cd /mnt/array-fastest/home/guyep/playground/2025-12-20-m40-llm/m40-llm
source scripts/dev-env.sh
while IFS=$'\t' read -r key value; do
  export "$key=$value"
done < <(head -n 1 docs/experiments/2026-10-25-maxwell-packed-projection-runtime-quality.jsonl |
  jq -r '.environment | to_entries[] | [.key,.value] | @tsv')
out=/tmp/m40-compound-runtime
test ! -e "$out/http.jsonl"
test -z "$(nvidia-smi --query-compute-apps=pid --format=csv,noheader)"
if curl -fsS --max-time 2 http://127.0.0.1:18435/api/version >/dev/null 2>&1; then
  printf '%s\n' 'Refusing to reuse an existing Ollama server' >&2
  exit 1
fi
nvidia-smi --query-gpu=uuid,pstate,temperature.gpu,clocks.sm,clocks.mem,power.draw --format=csv > "$out/before-http-gpu.csv"
git rev-parse HEAD > "$out/http.source"
OLLAMA_HOST=127.0.0.1:18435 OLLAMA_MODELS="$HOME/.ollama/models" \
OLLAMA_DEBUG=1 OLLAMA_NUM_PARALLEL=1 OLLAMA_MAX_LOADED_MODELS=1 \
OLLAMA_KEEP_ALIVE=30m OLLAMA_NO_CLOUD=1 OLLAMA_NOPRUNE=1 LLAMA_ARG_CACHE_RAM=0 \
  /tmp/m40-llm-tools/ollama-0.40.11/bin/ollama serve > "$out/ollama.log" 2>&1 &
daemon=$!
printf '%s\n' "$daemon" > "$out/ollama.pid"
cleanup() {
  kill "$daemon" 2>/dev/null || true
  wait "$daemon" 2>/dev/null || true
}
trap cleanup EXIT
for _ in $(seq 1 60); do
  kill -0 "$daemon"
  if curl -fsS --max-time 2 http://127.0.0.1:18435/api/version > "$out/ollama-version.json"; then
    break
  fi
  sleep 1
done
target/release/examples/compare_ollama \
  --model "$HOME/.ollama/models/blobs/sha256-4420ccb0f1d9e12811d04ae2a28ec881469305f813c62d86c10e595ef8e0111d" \
  --ollama-pid "$daemon" --ollama-log "$out/ollama.log" \
  --compare-q8-runtime joint-shared-scales-128 \
  --q8-runtime-prefill dequant-sgemm \
  --q8-runtime-control qualified-packed-projection-sgemm \
  --q8-runtime-attention packed-warp-256 \
  --q8-runtime-quality-report "$out/quality.jsonl" \
  --output "$out/http.jsonl" > "$out/http.log" 2>&1
