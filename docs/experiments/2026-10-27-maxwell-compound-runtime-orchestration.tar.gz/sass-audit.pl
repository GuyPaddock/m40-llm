#!/usr/bin/env perl
use strict;
use warnings;
use Digest::SHA qw(sha256_hex);
use JSON::PP;
sub read_functions {
    my ($path)=@_; open my $file,'<',$path or die $!;
    my (%functions,$name);
    while(my $line=<$file>) {
        $name=$1 if $line =~ /Function : (\S+)/;
        next unless defined $name;
        while($line =~ /0x([a-f0-9]{16})/g) {push @{$functions{$name}},"0x$1\n";}
    }
    close $file or die $!; return \%functions;
}
my $before=read_functions($ARGV[0]);my $after=read_functions($ARGV[1]);
die 'entry count changed' unless keys(%$before)==keys(%$after);
my @original;
for my $name(sort keys %$before) {
    die "missing $name" unless exists $after->{$name};
    my $old=join '',@{$before->{$name}};my $new=join '',@{$after->{$name}};
    die "changed $name" unless $old eq $new;
    push @original,{name=>$name,words=>scalar @{$after->{$name}},sha256=>sha256_hex($new)};
}
die 'expected 137 entries' unless @original==137;
print JSON::PP->new->canonical->pretty->encode({has_all_prior_words=>JSON::PP::true,
    entry_count=>scalar @original,original_entries=>\@original,added_entries=>[]});
