#!/usr/bin/env bash
set -euo pipefail
cd /mnt/array-fastest/home/guyep/playground/2025-12-20-m40-llm/m40-llm
source scripts/dev-env.sh
unset LD_PRELOAD M40LLM_CUDA_TRACE_PREFIX M40LLM_CUDA_TRACE_ACTIVITY M40LLM_CUDA_TRACE_CALLBACKS
while IFS=$'\t' read -r key value; do export "$key=$value"; done < <(
  head -n1 docs/experiments/2026-10-25-maxwell-packed-projection-runtime-quality.jsonl |
    jq -r '.environment|to_entries[]|[.key,.value]|@tsv')
export M40LLM_STAGE_PROFILE=0 M40LLM_STAGE_PROFILE_PREFILL=1
export M40LLM_STAGE_PROFILE_REPORT=/tmp/m40-prefill-nongemm-screen-events.jsonl
exec target/release/examples/compare_ollama \
  --model "$HOME/.ollama/models/blobs/sha256-4420ccb0f1d9e12811d04ae2a28ec881469305f813c62d86c10e595ef8e0111d" \
  --ollama-pid "$(< /tmp/m40-prefill-nongemm-oracle.pid)" \
  --ollama-log /tmp/m40-prefill-nongemm-oracle.log \
  --output /tmp/m40-prefill-nongemm-screen-http.jsonl \
  --compare-q8-runtime split-f32x4-128 --q8-runtime-prefill dequant-sgemm \
  --q8-runtime-control qualified-warp-sgemm --q8-runtime-attention packed-warp-256 \
  --q8-runtime-quality-report docs/experiments/2026-10-25-maxwell-packed-projection-runtime-quality.jsonl \
  --profile-q8-runtime > /tmp/m40-prefill-nongemm-screen-run.log 2>&1
