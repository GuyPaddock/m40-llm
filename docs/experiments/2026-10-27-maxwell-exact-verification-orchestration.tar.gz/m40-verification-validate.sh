#!/usr/bin/env bash
set -euo pipefail
cd /mnt/array-fastest/home/guyep/playground/2025-12-20-m40-llm/m40-llm
source scripts/dev-env.sh
mkdir -p /tmp/m40-verification
M40LLM_ENABLE_NVCC=1 M40LLM_ENABLE_CUBLAS=0 cargo test --features cuda --test exact_verification -- --include-ignored --test-threads=1 > /tmp/m40-verification/tests-off.log 2>&1
M40LLM_ENABLE_NVCC=1 M40LLM_ENABLE_CUBLAS=1 cargo test --features cuda --test attention_parity_cuda_grid --test forward_with_layer_smoke --test q8_ffn_joint -- --include-ignored --test-threads=1 > /tmp/m40-verification/regressions.log 2>&1
RUSTFLAGS='-D warnings' cargo test --no-default-features --locked > /tmp/m40-verification/noncuda.log 2>&1
M40LLM_ENABLE_NVCC=1 M40LLM_ENABLE_CUBLAS=1 cargo clippy --features cuda,server --all-targets -- -D warnings > /tmp/m40-verification/clippy.log 2>&1
cargo fmt --all -- --check
git diff --check
printf 'VERIFICATION_VALIDATION_COMPLETE\n'
