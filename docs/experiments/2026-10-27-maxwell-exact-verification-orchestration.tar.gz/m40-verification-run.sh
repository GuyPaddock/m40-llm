#!/usr/bin/env bash
set -euo pipefail
cd /mnt/array-fastest/home/guyep/playground/2025-12-20-m40-llm/m40-llm
source scripts/dev-env.sh
while IFS=$'\t' read -r key value; do export "$key=$value"; done < <(
  head -n1 docs/experiments/2026-10-25-maxwell-packed-projection-runtime-quality.jsonl |
  jq -r '.environment|to_entries[]|[.key,.value]|@tsv')
phase=${1:?preflight or screen}
[[ ! -e /tmp/m40-verification/$phase.jsonl ]]
[[ -z $(git status --short) ]]
[[ -z $(nvidia-smi --query-compute-apps=pid --format=csv,noheader) ]]
if [[ $phase == preflight ]]; then
  cargo build --release --features cuda --example q8_execution_bench > /tmp/m40-verification/build.log 2>&1
fi
git rev-parse HEAD > /tmp/m40-verification/$phase.source
sha256sum target/release/examples/q8_execution_bench > /tmp/m40-verification/$phase.executable
printf '%s\n' "$$" > /tmp/m40-verification/$phase.pid
options=()
if [[ $phase == preflight ]]; then options+=(--verification-only-preflight); fi
exec target/release/examples/q8_execution_bench \
  --model "$HOME/.ollama/models/blobs/sha256-4420ccb0f1d9e12811d04ae2a28ec881469305f813c62d86c10e595ef8e0111d" \
  --verification-trace docs/experiments/2026-10-25-maxwell-packed-projection-runtime-quality.jsonl \
  --rows 2,4,8 --trials 5 "${options[@]}" \
  --output "/tmp/m40-verification/$phase.jsonl" > "/tmp/m40-verification/$phase.log" 2>&1
