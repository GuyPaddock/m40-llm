#!/usr/bin/env bash
# Run only unchanged FFN work; restore all temporary GPU policy changes.
set -euo pipefail
cd /mnt/array-fastest/home/guyep/playground/2025-12-20-m40-llm/m40-llm
source scripts/dev-env.sh
directory=/tmp/m40-sm-clock-screen
gpu=GPU-e590a24b-e805-dbcd-2e8b-b991dfe1f852
executable=target/release/examples/q8_execution_bench
mkdir "$directory"
child=
has_mutated=0

read_policy() {
  nvidia-smi -i "$gpu" --query-gpu=uuid,persistence_mode,clocks.applications.memory,clocks.applications.graphics,clocks.default_applications.memory,clocks.default_applications.graphics --format=csv,noheader,nounits | sed 's/, */,/g'
}

read_boost() {
  nvidia-smi -i "$gpu" -q -d CLOCK | awk '/^[[:space:]]*Auto Boost[[:space:]]*:/{current=$NF} /^[[:space:]]*Auto Boost Default[[:space:]]*:/{print current "," $NF}'
}

take_snapshot() {
  read_policy > "$directory/$1-policy.csv"
  read_boost > "$directory/$1-boost.csv"
  nvidia-smi -i "$gpu" --query-compute-apps=pid,process_name,used_memory --format=csv,noheader > "$directory/$1-processes.csv"
}

restore_policy() {
  status=$?
  trap - EXIT INT TERM
  set +e
  if [[ -n "$child" ]] && kill -0 "$child" 2>/dev/null; then
    kill -TERM "$child"
    wait "$child"
  fi
  if [[ $has_mutated == 1 ]]; then
    sudo -n nvidia-smi -i "$gpu" -rac >> "$directory/restore.log" 2>&1
    sudo -n nvidia-smi -i "$gpu" --auto-boost-default=1 >> "$directory/restore.log" 2>&1
    sudo -n nvidia-smi -i "$gpu" -pm 0 >> "$directory/restore.log" 2>&1
  fi
  take_snapshot final
  is_restored=false
  if cmp -s "$directory/before-policy.csv" "$directory/final-policy.csv" &&
      cmp -s "$directory/before-boost.csv" "$directory/final-boost.csv" &&
      [[ ! -s "$directory/final-processes.csv" ]]; then
    is_restored=true
  fi
  jq -n --argjson exit_code "$status" --argjson has_mutated "$has_mutated" --argjson is_restored "$is_restored" \
    '{exit_code:$exit_code,has_mutated:($has_mutated==1),is_original_policy_restored:$is_restored}' > "$directory/completion.json"
  if [[ $is_restored != true ]]; then
    printf 'GPU policy restoration requires attention: %s\n' "$directory" >&2
    exit 97
  fi
  printf 'Original GPU policy restored; diagnostic exit=%s\n' "$status"
  exit "$status"
}

take_snapshot before
trap restore_policy EXIT
trap 'exit 130' INT
trap 'exit 143' TERM
[[ ! -s "$directory/before-processes.csv" ]]
[[ $(< "$directory/before-policy.csv") == "$gpu,Disabled,3004,947,3004,947" ]]
[[ $(< "$directory/before-boost.csv") == On,On ]]
[[ -z $(git status --porcelain) ]]
while IFS=$'\t' read -r key value; do export "$key=$value"; done < <(
  head -n1 docs/experiments/2026-10-25-maxwell-ffn-capture.jsonl |
    jq -r '.execution_configuration.environment|to_entries[]|[.key,.value]|@tsv')
unset LD_PRELOAD M40LLM_CUDA_TRACE_PREFIX M40LLM_CUDA_TRACE_ACTIVITY M40LLM_CUDA_TRACE_CALLBACKS
unset M40LLM_STAGE_PROFILE M40LLM_STAGE_PROFILE_PREFILL M40LLM_STAGE_PROFILE_REPORT
sha256sum "$executable" /tmp/m40-sm-clock-run.sh > "$directory/executables.sha256"
git rev-parse HEAD > "$directory/source.txt"
nvidia-smi -i "$gpu" --query-supported-clocks=memory,graphics --format=csv > "$directory/supported-clocks.csv"
has_mutated=1
sudo -n nvidia-smi -i "$gpu" -pm 1 > "$directory/settings.log" 2>&1
sudo -n nvidia-smi -i "$gpu" --auto-boost-default=0 >> "$directory/settings.log" 2>&1
[[ $(read_boost) == Off,Off ]]

for pair in 0 1 2 3 4; do
  states=(high low)
  if (( pair % 2 == 1 )); then states=(low high); fi
  for state in "${states[@]}"; do
    clock=1114
    if [[ $state == low ]]; then clock=823; fi
    prefix="$directory/pair-$pair-$state"
    take_snapshot "pair-$pair-$state-before"
    [[ ! -s "$directory/pair-$pair-$state-before-processes.csv" ]]
    sudo -n nvidia-smi -i "$gpu" --applications-clocks="3004,$clock" >> "$directory/settings.log" 2>&1
    take_snapshot "pair-$pair-$state-configured"
    [[ ! -s "$directory/pair-$pair-$state-configured-processes.csv" ]]
    [[ $(read_boost) == Off,Off ]]
    printf 'Starting outer pair=%s state=%s requested_sm=%s memory=3004\n' "$pair" "$state" "$clock"
    "$executable" \
      --model "$HOME/.ollama/models/blobs/sha256-4420ccb0f1d9e12811d04ae2a28ec881469305f813c62d86c10e595ef8e0111d" \
      --ffn-inputs target/research-fixtures/m02-ffn-inputs.json \
      --ffn-capture-report docs/experiments/2026-10-25-maxwell-ffn-capture.jsonl \
      --ffn-weight-read --rows 1,4 --trials 5 --iterations 10 \
      --output "$prefix.jsonl" > "$prefix.log" 2>&1 &
    child=$!
    printf '%s\n' "$child" > "$prefix.pid"
    wait "$child"
    pid=$child
    child=
    take_snapshot "pair-$pair-$state-after"
    [[ ! -s "$directory/pair-$pair-$state-after-processes.csv" ]]
    jq -es --argjson requested "$clock" --argjson pid "$pid" --arg gpu "$gpu" '
      [.[]|select(.kind=="ffn_read_pair")] as $pairs |
      ($pairs|length)==30 and .[-1].kind=="ffn_read_complete" and .[-1].is_complete
      and .[-1].device_bytes_after==.[-1].device_bytes_before
      and all($pairs[];all([.gpu_before,.gpu_after][];
        (.device|split(",")|map(gsub("^ +| +$";""))) as $d |
        $d[0]==$gpu and $d[3]=="P0" and ($d[6]|split(" ")[0]|tonumber)==3004
        and ((($d[5]|split(" ")[0]|tonumber)-$requested)|fabs)<=2
        and (.processes|split("\n")|map(split(",")[0]|tonumber))==[$pid]))
    ' "$prefix.jsonl" > "$prefix-boundary-audit.json"
    jq -nc --argjson pair "$pair" --arg state "$state" --argjson requested "$clock" --argjson pid "$pid" \
      --arg report "$prefix.jsonl" '{pair:$pair,state:$state,requested_sm_mhz:$requested,pid:$pid,report:$report,exit_code:0}' >> "$directory/processes.jsonl"
    printf 'Completed outer pair=%s state=%s pid=%s; all measured boundaries valid\n' "$pair" "$state" "$pid"
  done
done
