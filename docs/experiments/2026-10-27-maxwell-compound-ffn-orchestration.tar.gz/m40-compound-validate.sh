#!/usr/bin/env bash
set -euo pipefail
cd /mnt/array-fastest/home/guyep/playground/2025-12-20-m40-llm/m40-llm
source scripts/dev-env.sh
while IFS=$'\t' read -r key value; do export "$key=$value"; done < <(
  head -n1 docs/experiments/2026-10-25-maxwell-ffn-capture.jsonl |
  jq -r '.execution_configuration.environment|to_entries[]|[.key,.value]|@tsv')
mkdir -p /tmp/m40-compound
nvidia-smi --query-compute-apps=pid,process_name,used_memory --format=csv
cargo build --release --features cuda --example q8_execution_bench > /tmp/m40-compound/build.log 2>&1
for cublas in 1 0; do
  M40LLM_ENABLE_CUBLAS=$cublas cargo test --features cuda --test q8_ffn_joint -- --include-ignored --test-threads=1 > /tmp/m40-compound/joint-$cublas.log 2>&1
  M40LLM_ENABLE_CUBLAS=$cublas cargo test --features cuda --example q8_execution_bench compound -- --include-ignored --test-threads=1 > /tmp/m40-compound/compound-$cublas.log 2>&1
done
M40LLM_ENABLE_CUBLAS=1 cargo test --features cuda --example q8_execution_bench -- --test-threads=1 > /tmp/m40-compound/example.log 2>&1
for key in ${!M40LLM_@}; do unset "$key"; done
export M40LLM_ENABLE_NVCC=1 M40LLM_ENABLE_CUBLAS=1
M40LLM_ENABLE_CUBLAS=1 cargo test --features cuda --test attention_parity_cuda_grid --test proj_wrappers --test mlp_wrappers --test forward_with_layer_smoke -- --test-threads=1 > /tmp/m40-compound/regressions-clean-env.log 2>&1
RUSTFLAGS='-D warnings' cargo test --no-default-features --locked > /tmp/m40-compound/noncuda.log 2>&1
M40LLM_ENABLE_CUBLAS=1 cargo clippy --features cuda,server --all-targets -- -D warnings > /tmp/m40-compound/clippy.log 2>&1
cargo fmt --all -- --check
git diff --check
printf 'COMPOUND_VALIDATION_COMPLETE\n'
