#!/usr/bin/env bash
set -euo pipefail
cd /mnt/array-fastest/home/guyep/playground/2025-12-20-m40-llm/m40-llm
source scripts/dev-env.sh
while IFS=$'\t' read -r key value; do export "$key=$value"; done < <(
  head -n1 docs/experiments/2026-10-25-maxwell-ffn-capture.jsonl |
  jq -r '.execution_configuration.environment|to_entries[]|[.key,.value]|@tsv')
directory=/tmp/m40-compound
phase=${1:?screen or confirm}
trials=${2:?trial count}
[[ ! -e "$directory/$phase.jsonl" ]]
[[ -z $(git status --short) ]]
[[ -z $(nvidia-smi --query-compute-apps=pid --format=csv,noheader) ]]
git rev-parse HEAD > "$directory/$phase.source"
sha256sum target/release/examples/q8_execution_bench > "$directory/$phase.executable"
printf '%s\n' "$$" > "$directory/$phase.pid"
exec target/release/examples/q8_execution_bench \
  --model "$HOME/.ollama/models/blobs/sha256-4420ccb0f1d9e12811d04ae2a28ec881469305f813c62d86c10e595ef8e0111d" \
  --ffn-inputs target/research-fixtures/m02-ffn-inputs.json \
  --ffn-capture-report docs/experiments/2026-10-25-maxwell-ffn-capture.jsonl \
  --ffn-f32-compound --rows 1,4 --trials "$trials" --iterations 10 \
  --output "$directory/$phase.jsonl" > "$directory/$phase.log" 2>&1
