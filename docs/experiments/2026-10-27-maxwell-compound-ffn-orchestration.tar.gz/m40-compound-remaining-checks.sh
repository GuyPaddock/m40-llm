#!/usr/bin/env bash
set -euo pipefail
cd /mnt/array-fastest/home/guyep/playground/2025-12-20-m40-llm/m40-llm
for key in ${!M40LLM_@}; do unset "$key"; done
source scripts/dev-env.sh
export M40LLM_ENABLE_NVCC=1 M40LLM_ENABLE_CUBLAS=1
cargo test --features cuda --test attention_parity_cuda_grid --test proj_wrappers --test mlp_wrappers --test forward_with_layer_smoke -- --test-threads=1 > /tmp/m40-compound/regressions-isolated-env.log 2>&1
RUSTFLAGS='-D warnings' cargo test --no-default-features --locked > /tmp/m40-compound/noncuda.log 2>&1
cargo clippy --features cuda,server --all-targets -- -D warnings > /tmp/m40-compound/clippy.log 2>&1
cargo fmt --all -- --check
git diff --check
printf 'COMPOUND_REMAINING_VALIDATION_COMPLETE\n'
