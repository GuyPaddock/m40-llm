#!/usr/bin/env bash
# CPU-only, source-verified fixed-coordinate information scan.
set -euo pipefail
cd /mnt/array-fastest/home/guyep/playground/2025-12-20-m40-llm/m40-llm
directory=/tmp/m40-channel-entropy-screen
model="$HOME/.ollama/models/blobs/sha256-4420ccb0f1d9e12811d04ae2a28ec881469305f813c62d86c10e595ef8e0111d"
mkdir "$directory"
trap 'rm -f "$directory/tensor.bin"' EXIT
[[ -z $(git status --porcelain) ]]
export CUDA_VISIBLE_DEVICES=-1
unset LD_PRELOAD
ulimit -v 524288
sha256sum /tmp/m40-channel-entropy.pl /tmp/m40-channel-entropy-run.sh > "$directory/scanners.sha256"
git rev-parse HEAD > "$directory/source.txt"
sha256sum "$model" > "$directory/model.sha256"
[[ $(cut -d' ' -f1 "$directory/model.sha256") == 4420ccb0f1d9e12811d04ae2a28ec881469305f813c62d86c10e595ef8e0111d ]]
jq -cs '[.[]|select(.kind=="ffn_payload_entropy_tensor")]|if length==6
  and (map([.layer_id,.family])|sort)==[[0,"gate"],[0,"up"],[17,"gate"],[17,"up"],[35,"gate"],[35,"up"]]
  and all(.[];.source.dtype=="Q8_0" and .source.shape==[2048,11008] and .raw_tensor_buffer_bytes==23953408)
  then .[] else error("invalid frozen source coverage") end' \
  docs/experiments/2026-10-26-maxwell-ffn-entropy-study.jsonl > "$directory/frozen-sources.jsonl"
while IFS= read -r record; do
  layer=$(jq -r .layer_id <<< "$record")
  family=$(jq -r .family <<< "$record")
  offset=$(jq -r .absolute_file_offset <<< "$record")
  prefix="$directory/layer-$layer-$family"
  printf 'Scanning layer=%s family=%s, original tensor SHA required\n' "$layer" "$family"
  dd if="$model" of="$directory/tensor.bin" iflag=skip_bytes,count_bytes skip="$offset" count=23953408 status=none
  sha256sum "$directory/tensor.bin" > "$prefix-source.sha256"
  [[ $(cut -d' ' -f1 "$prefix-source.sha256") == "$(jq -r .source.source_sha256 <<< "$record")" ]]
  /usr/bin/time -v -o "$prefix-resources.log" timeout --signal=TERM --kill-after=5 180 \
    perl /tmp/m40-channel-entropy.pl "$directory/tensor.bin" 2048 11008 |
    gzip -cn > "$prefix-statistics.json.gz"
  od -An -v -tu1 -w2176 "$directory/tensor.bin" | awk '
    BEGIN { index[0]=3; index[31]=34; index[32]=37; index[2047]=2176 }
    NF!=2176 { bad=1; exit 2 }
    { for(channel in index) histogram[channel,$index[channel]]++ }
    END {
      if(bad) exit 2
      for(channel in index) {
        printf "{\"input_channel\":%d,\"histogram\":[",channel
        for(value=0;value<256;value++) printf "%s%d",(value?",":""),histogram[channel,value]+0
        print "]}"
      }
    }' > "$prefix-independent.jsonl"
  gzip -dc "$prefix-statistics.json.gz" | jq -e --argjson original "$record" \
    --slurpfile independent "$prefix-independent.jsonl" '
    .statistics as $s | $s.pooled_histogram==$original.statistics.payload_histogram
    and (($s.pooled_entropy_bits-$original.statistics.zero_order_entropy_bits_per_symbol)|fabs)<1e-9
    and ($s.channels|length)==2048 and .loaded_cuda_libraries==[]
    and ($independent|map(.input_channel)|sort)==[0,31,32,2047]
    and all($independent[];. as $check|$s.channels[$check.input_channel].histogram==$check.histogram)
  ' > "$prefix-count-audit.json"
  gzip -dc "$prefix-statistics.json.gz" | jq -c --argjson layer "$layer" --arg family "$family" \
    '{layer_id:$layer,family:$family,pooled_entropy_bits:.statistics.pooled_entropy_bits,
      conditional_entropy_bits:.statistics.conditional_entropy_bits,
      optimistic_stored_byte_saving:.statistics.optimistic_stored_byte_saving}' >> "$directory/summary.jsonl"
  printf 'Completed layer=%s family=%s; pooled and sampled-channel counts match\n' "$layer" "$family"
done < "$directory/frozen-sources.jsonl"
jq -ns '{is_complete:true,tensors:6,has_created_cuda_context:false,has_encoder:false,has_decoder:false,
  is_performance_measurement:false,scope:"fixed input-coordinate information scan, not encoded size or inference speed"}' > "$directory/completion.json"
