
target/release/examples/cpu_projection_probe:     file format elf64-x86-64


Disassembly of section .text:

0000000000083450 <cpu_projection_probe::kernel::Q8Matrix::project_avx2_unchecked>:
   83450:	55                   	push   %rbp
   83451:	41 57                	push   %r15
   83453:	41 56                	push   %r14
   83455:	41 55                	push   %r13
   83457:	41 54                	push   %r12
   83459:	53                   	push   %rbx
   8345a:	48 81 ec a8 00 00 00 	sub    $0xa8,%rsp
   83461:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
   83466:	4c 8b 4f 20          	mov    0x20(%rdi),%r9
   8346a:	4d 85 c9             	test   %r9,%r9
   8346d:	0f 84 76 03 00 00    	je     837e9 <cpu_projection_probe::kernel::Q8Matrix::project_avx2_unchecked+0x399>
   83473:	48 83 7c 24 08 00    	cmpq   $0x0,0x8(%rsp)
   83479:	0f 84 6a 03 00 00    	je     837e9 <cpu_projection_probe::kernel::Q8Matrix::project_avx2_unchecked+0x399>
   8347f:	4c 8b 57 18          	mov    0x18(%rdi),%r10
   83483:	4c 89 d3             	mov    %r10,%rbx
   83486:	48 c1 eb 05          	shr    $0x5,%rbx
   8348a:	0f 84 2e 03 00 00    	je     837be <cpu_projection_probe::kernel::Q8Matrix::project_avx2_unchecked+0x36e>
   83490:	4c 8b 5f 08          	mov    0x8(%rdi),%r11
   83494:	48 8b 57 10          	mov    0x10(%rdi),%rdx
   83498:	48 83 c6 60          	add    $0x60,%rsi
   8349c:	49 c1 e2 02          	shl    $0x2,%r10
   834a0:	48 89 d8             	mov    %rbx,%rax
   834a3:	48 c1 e0 05          	shl    $0x5,%rax
   834a7:	48 8d 04 58          	lea    (%rax,%rbx,2),%rax
   834ab:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
   834b0:	48 c7 04 24 00 00 00 	movq   $0x0,(%rsp)
   834b7:	00 
   834b8:	45 31 f6             	xor    %r14d,%r14d
   834bb:	48 89 54 24 18       	mov    %rdx,0x18(%rsp)
   834c0:	4c 89 5c 24 10       	mov    %r11,0x10(%rsp)
   834c5:	4c 89 44 24 58       	mov    %r8,0x58(%rsp)
   834ca:	48 89 4c 24 48       	mov    %rcx,0x48(%rsp)
   834cf:	4c 89 4c 24 50       	mov    %r9,0x50(%rsp)
   834d4:	48 89 74 24 28       	mov    %rsi,0x28(%rsp)
   834d9:	4c 89 54 24 40       	mov    %r10,0x40(%rsp)
   834de:	48 89 5c 24 38       	mov    %rbx,0x38(%rsp)
   834e3:	49 8d 46 01          	lea    0x1(%r14),%rax
   834e7:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
   834ec:	49 89 f5             	mov    %rsi,%r13
   834ef:	31 c0                	xor    %eax,%eax
   834f1:	4c 89 74 24 60       	mov    %r14,0x60(%rsp)
   834f6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   834fd:	00 00 00 
   83500:	48 89 44 24 78       	mov    %rax,0x78(%rsp)
   83505:	48 ff c0             	inc    %rax
   83508:	48 89 44 24 68       	mov    %rax,0x68(%rsp)
   8350d:	c5 e8 57 d2          	vxorps %xmm2,%xmm2,%xmm2
   83511:	4c 8b 24 24          	mov    (%rsp),%r12
   83515:	4c 89 6c 24 70       	mov    %r13,0x70(%rsp)
   8351a:	e9 a1 00 00 00       	jmp    835c0 <cpu_projection_probe::kernel::Q8Matrix::project_avx2_unchecked+0x170>
   8351f:	90                   	nop
   83520:	c5 fc 11 94 24 80 00 	vmovups %ymm2,0x80(%rsp)
   83527:	00 00 
   83529:	44 89 ff             	mov    %r15d,%edi
   8352c:	c5 f8 77             	vzeroupper
   8352f:	e8 9c 0a 00 00       	call   83fd0 <half::binary16::arch::x86::f16_to_f32_x86_f16c>
   83534:	c5 fc 10 94 24 80 00 	vmovups 0x80(%rsp),%ymm2
   8353b:	00 00 
   8353d:	4c 8b 5c 24 10       	mov    0x10(%rsp),%r11
   83542:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
   83547:	c4 e2 7d 58 c0       	vpbroadcastd %xmm0,%ymm0
   8354c:	c4 82 7d 21 4c 23 02 	vpmovsxbd 0x2(%r11,%r12,1),%ymm1
   83553:	c5 fc 5b c9          	vcvtdq2ps %ymm1,%ymm1
   83557:	c5 fc 59 c9          	vmulps %ymm1,%ymm0,%ymm1
   8355b:	c4 c1 74 59 4d a0    	vmulps -0x60(%r13),%ymm1,%ymm1
   83561:	c5 ec 58 c9          	vaddps %ymm1,%ymm2,%ymm1
   83565:	c4 82 7d 21 54 23 0a 	vpmovsxbd 0xa(%r11,%r12,1),%ymm2
   8356c:	c5 fc 5b d2          	vcvtdq2ps %ymm2,%ymm2
   83570:	c5 fc 59 d2          	vmulps %ymm2,%ymm0,%ymm2
   83574:	c4 c1 6c 59 55 c0    	vmulps -0x40(%r13),%ymm2,%ymm2
   8357a:	c4 82 7d 21 5c 23 12 	vpmovsxbd 0x12(%r11,%r12,1),%ymm3
   83581:	c5 fc 5b db          	vcvtdq2ps %ymm3,%ymm3
   83585:	c5 fc 59 db          	vmulps %ymm3,%ymm0,%ymm3
   83589:	c4 c1 64 59 5d e0    	vmulps -0x20(%r13),%ymm3,%ymm3
   8358f:	c5 f4 58 ca          	vaddps %ymm2,%ymm1,%ymm1
   83593:	c5 f4 58 cb          	vaddps %ymm3,%ymm1,%ymm1
   83597:	c4 82 7d 21 54 23 1a 	vpmovsxbd 0x1a(%r11,%r12,1),%ymm2
   8359e:	c5 fc 5b d2          	vcvtdq2ps %ymm2,%ymm2
   835a2:	c5 fc 59 c2          	vmulps %ymm2,%ymm0,%ymm0
   835a6:	c4 c1 7c 59 45 00    	vmulps 0x0(%r13),%ymm0,%ymm0
   835ac:	c5 f4 58 d0          	vaddps %ymm0,%ymm1,%ymm2
   835b0:	49 83 ed 80          	sub    $0xffffffffffffff80,%r13
   835b4:	49 89 ec             	mov    %rbp,%r12
   835b7:	48 ff cb             	dec    %rbx
   835ba:	0f 84 30 01 00 00    	je     836f0 <cpu_projection_probe::kernel::Q8Matrix::project_avx2_unchecked+0x2a0>
   835c0:	49 83 fc dd          	cmp    $0xffffffffffffffdd,%r12
   835c4:	0f 87 dc 01 00 00    	ja     837a6 <cpu_projection_probe::kernel::Q8Matrix::project_avx2_unchecked+0x356>
   835ca:	49 8d 6c 24 22       	lea    0x22(%r12),%rbp
   835cf:	48 39 d5             	cmp    %rdx,%rbp
   835d2:	0f 87 ce 01 00 00    	ja     837a6 <cpu_projection_probe::kernel::Q8Matrix::project_avx2_unchecked+0x356>
   835d8:	47 0f b6 3c 23       	movzbl (%r11,%r12,1),%r15d
   835dd:	47 0f b6 74 23 01    	movzbl 0x1(%r11,%r12,1),%r14d
   835e3:	41 c1 e6 08          	shl    $0x8,%r14d
   835e7:	45 09 f7             	or     %r14d,%r15d
   835ea:	48 8b 05 5f 0f 0d 00 	mov    0xd0f5f(%rip),%rax        # 154550 <_DYNAMIC+0x278>
   835f1:	48 8b 00             	mov    (%rax),%rax
   835f4:	48 85 c0             	test   %rax,%rax
   835f7:	0f 84 b3 00 00 00    	je     836b0 <cpu_projection_probe::kernel::Q8Matrix::project_avx2_unchecked+0x260>
   835fd:	48 0f ba e0 37       	bt     $0x37,%rax
   83602:	0f 82 18 ff ff ff    	jb     83520 <cpu_projection_probe::kernel::Q8Matrix::project_avx2_unchecked+0xd0>
   83608:	41 f7 c7 ff 7f 00 00 	test   $0x7fff,%r15d
   8360f:	74 37                	je     83648 <cpu_projection_probe::kernel::Q8Matrix::project_avx2_unchecked+0x1f8>
   83611:	44 89 f0             	mov    %r14d,%eax
   83614:	41 81 e6 00 80 00 00 	and    $0x8000,%r14d
   8361b:	25 00 7c 00 00       	and    $0x7c00,%eax
   83620:	41 81 e7 ff 03 00 00 	and    $0x3ff,%r15d
   83627:	41 c1 e6 10          	shl    $0x10,%r14d
   8362b:	3d 00 7c 00 00       	cmp    $0x7c00,%eax
   83630:	75 1c                	jne    8364e <cpu_projection_probe::kernel::Q8Matrix::project_avx2_unchecked+0x1fe>
   83632:	66 45 85 ff          	test   %r15w,%r15w
   83636:	74 39                	je     83671 <cpu_projection_probe::kernel::Q8Matrix::project_avx2_unchecked+0x221>
   83638:	41 c1 e7 0d          	shl    $0xd,%r15d
   8363c:	45 09 f7             	or     %r14d,%r15d
   8363f:	41 81 cf 00 00 c0 7f 	or     $0x7fc00000,%r15d
   83646:	eb 5e                	jmp    836a6 <cpu_projection_probe::kernel::Q8Matrix::project_avx2_unchecked+0x256>
   83648:	41 c1 e7 10          	shl    $0x10,%r15d
   8364c:	eb 58                	jmp    836a6 <cpu_projection_probe::kernel::Q8Matrix::project_avx2_unchecked+0x256>
   8364e:	66 85 c0             	test   %ax,%ax
   83651:	74 27                	je     8367a <cpu_projection_probe::kernel::Q8Matrix::project_avx2_unchecked+0x22a>
   83653:	0f b7 c0             	movzwl %ax,%eax
   83656:	c1 e0 0d             	shl    $0xd,%eax
   83659:	25 00 00 80 0f       	and    $0xf800000,%eax
   8365e:	41 c1 e7 0d          	shl    $0xd,%r15d
   83662:	41 01 c7             	add    %eax,%r15d
   83665:	41 81 c7 00 00 00 38 	add    $0x38000000,%r15d
   8366c:	45 09 f7             	or     %r14d,%r15d
   8366f:	eb 35                	jmp    836a6 <cpu_projection_probe::kernel::Q8Matrix::project_avx2_unchecked+0x256>
   83671:	41 81 ce 00 00 80 7f 	or     $0x7f800000,%r14d
   83678:	eb 29                	jmp    836a3 <cpu_projection_probe::kernel::Q8Matrix::project_avx2_unchecked+0x253>
   8367a:	66 b8 1f 00          	mov    $0x1f,%ax
   8367e:	66 41 0f bd c7       	bsr    %r15w,%ax
   83683:	83 f0 0f             	xor    $0xf,%eax
   83686:	8d 48 08             	lea    0x8(%rax),%ecx
   83689:	41 d3 e7             	shl    %cl,%r15d
   8368c:	41 81 e7 ff ff 7f 00 	and    $0x7fffff,%r15d
   83693:	41 81 ce 00 00 00 3b 	or     $0x3b000000,%r14d
   8369a:	c1 e0 17             	shl    $0x17,%eax
   8369d:	41 29 c6             	sub    %eax,%r14d
   836a0:	45 09 fe             	or     %r15d,%r14d
   836a3:	45 89 f7             	mov    %r14d,%r15d
   836a6:	c4 c1 79 6e c7       	vmovd  %r15d,%xmm0
   836ab:	e9 97 fe ff ff       	jmp    83547 <cpu_projection_probe::kernel::Q8Matrix::project_avx2_unchecked+0xf7>
   836b0:	c5 fc 11 94 24 80 00 	vmovups %ymm2,0x80(%rsp)
   836b7:	00 00 
   836b9:	c5 f8 77             	vzeroupper
   836bc:	ff 15 d6 0e 0d 00    	call   *0xd0ed6(%rip)        # 154598 <_DYNAMIC+0x2c0>
   836c2:	c5 fc 10 94 24 80 00 	vmovups 0x80(%rsp),%ymm2
   836c9:	00 00 
   836cb:	4c 8b 5c 24 10       	mov    0x10(%rsp),%r11
   836d0:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
   836d5:	48 0f ba e0 37       	bt     $0x37,%rax
   836da:	0f 83 28 ff ff ff    	jae    83608 <cpu_projection_probe::kernel::Q8Matrix::project_avx2_unchecked+0x1b8>
   836e0:	e9 3b fe ff ff       	jmp    83520 <cpu_projection_probe::kernel::Q8Matrix::project_avx2_unchecked+0xd0>
   836e5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
   836ec:	00 00 00 00 
   836f0:	4c 8b 4c 24 50       	mov    0x50(%rsp),%r9
   836f5:	48 8b 7c 24 78       	mov    0x78(%rsp),%rdi
   836fa:	49 0f af f9          	imul   %r9,%rdi
   836fe:	4c 8b 74 24 60       	mov    0x60(%rsp),%r14
   83703:	4c 01 f7             	add    %r14,%rdi
   83706:	4c 8b 44 24 58       	mov    0x58(%rsp),%r8
   8370b:	4c 39 c7             	cmp    %r8,%rdi
   8370e:	0f 83 ea 00 00 00    	jae    837fe <cpu_projection_probe::kernel::Q8Matrix::project_avx2_unchecked+0x3ae>
   83714:	c5 fa 16 c2          	vmovshdup %xmm2,%xmm0
   83718:	c5 ea 58 c0          	vaddss %xmm0,%xmm2,%xmm0
   8371c:	c5 e9 c6 ca 01       	vshufpd $0x1,%xmm2,%xmm2,%xmm1
   83721:	c5 fa 58 c1          	vaddss %xmm1,%xmm0,%xmm0
   83725:	c5 e8 c6 ca ff       	vshufps $0xff,%xmm2,%xmm2,%xmm1
   8372a:	c5 fa 58 c1          	vaddss %xmm1,%xmm0,%xmm0
   8372e:	c4 e3 7d 19 d1 01    	vextractf128 $0x1,%ymm2,%xmm1
   83734:	c5 fa 58 c1          	vaddss %xmm1,%xmm0,%xmm0
   83738:	c5 fa 16 d1          	vmovshdup %xmm1,%xmm2
   8373c:	c5 fa 58 c2          	vaddss %xmm2,%xmm0,%xmm0
   83740:	c5 f1 c6 d1 01       	vshufpd $0x1,%xmm1,%xmm1,%xmm2
   83745:	c5 fa 58 c2          	vaddss %xmm2,%xmm0,%xmm0
   83749:	c5 f0 c6 c9 ff       	vshufps $0xff,%xmm1,%xmm1,%xmm1
   8374e:	c5 fa 58 c1          	vaddss %xmm1,%xmm0,%xmm0
   83752:	48 8b 4c 24 48       	mov    0x48(%rsp),%rcx
   83757:	c5 fa 11 04 b9       	vmovss %xmm0,(%rcx,%rdi,4)
   8375c:	4c 8b 54 24 40       	mov    0x40(%rsp),%r10
   83761:	4c 8b 6c 24 70       	mov    0x70(%rsp),%r13
   83766:	4d 01 d5             	add    %r10,%r13
   83769:	48 8b 74 24 68       	mov    0x68(%rsp),%rsi
   8376e:	48 89 f0             	mov    %rsi,%rax
   83771:	48 3b 74 24 08       	cmp    0x8(%rsp),%rsi
   83776:	48 8b 5c 24 38       	mov    0x38(%rsp),%rbx
   8377b:	0f 85 7f fd ff ff    	jne    83500 <cpu_projection_probe::kernel::Q8Matrix::project_avx2_unchecked+0xb0>
   83781:	48 8b 04 24          	mov    (%rsp),%rax
   83785:	48 03 44 24 20       	add    0x20(%rsp),%rax
   8378a:	48 89 04 24          	mov    %rax,(%rsp)
   8378e:	48 8b 44 24 30       	mov    0x30(%rsp),%rax
   83793:	49 89 c6             	mov    %rax,%r14
   83796:	4c 39 c8             	cmp    %r9,%rax
   83799:	48 8b 74 24 28       	mov    0x28(%rsp),%rsi
   8379e:	0f 85 3f fd ff ff    	jne    834e3 <cpu_projection_probe::kernel::Q8Matrix::project_avx2_unchecked+0x93>
   837a4:	eb 43                	jmp    837e9 <cpu_projection_probe::kernel::Q8Matrix::project_avx2_unchecked+0x399>
   837a6:	49 8d 74 24 22       	lea    0x22(%r12),%rsi
   837ab:	48 8d 0d a6 ac 0c 00 	lea    0xcaca6(%rip),%rcx        # 14e458 <anon.97d012cd1ae953ceed47d318d72a0976.3.llvm.12435647506851772847+0x100>
   837b2:	4c 89 e7             	mov    %r12,%rdi
   837b5:	c5 f8 77             	vzeroupper
   837b8:	ff 15 82 0d 0d 00    	call   *0xd0d82(%rip)        # 154540 <_DYNAMIC+0x268>
   837be:	31 c0                	xor    %eax,%eax
   837c0:	48 89 c7             	mov    %rax,%rdi
   837c3:	48 ff c0             	inc    %rax
   837c6:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
   837cb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
   837d0:	4c 39 c7             	cmp    %r8,%rdi
   837d3:	73 29                	jae    837fe <cpu_projection_probe::kernel::Q8Matrix::project_avx2_unchecked+0x3ae>
   837d5:	c7 04 b9 00 00 00 00 	movl   $0x0,(%rcx,%rdi,4)
   837dc:	4c 01 cf             	add    %r9,%rdi
   837df:	48 ff ca             	dec    %rdx
   837e2:	75 ec                	jne    837d0 <cpu_projection_probe::kernel::Q8Matrix::project_avx2_unchecked+0x380>
   837e4:	4c 39 c8             	cmp    %r9,%rax
   837e7:	75 d7                	jne    837c0 <cpu_projection_probe::kernel::Q8Matrix::project_avx2_unchecked+0x370>
   837e9:	48 81 c4 a8 00 00 00 	add    $0xa8,%rsp
   837f0:	5b                   	pop    %rbx
   837f1:	41 5c                	pop    %r12
   837f3:	41 5d                	pop    %r13
   837f5:	41 5e                	pop    %r14
   837f7:	41 5f                	pop    %r15
   837f9:	5d                   	pop    %rbp
   837fa:	c5 f8 77             	vzeroupper
   837fd:	c3                   	ret
   837fe:	48 8d 15 3b ac 0c 00 	lea    0xcac3b(%rip),%rdx        # 14e440 <anon.97d012cd1ae953ceed47d318d72a0976.3.llvm.12435647506851772847+0xe8>
   83805:	4c 89 c6             	mov    %r8,%rsi
   83808:	c5 f8 77             	vzeroupper
   8380b:	ff 15 ef 0d 0d 00    	call   *0xd0def(%rip)        # 154600 <_DYNAMIC+0x328>
